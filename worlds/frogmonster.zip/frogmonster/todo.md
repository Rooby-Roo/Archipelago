# Things to make it playable:

coins
Finish location access rules
Write region access rules
subdivide moridono's?
subdivide ridge
fix events
Write region access builder
Write bug region builder
Special bug handling (eel, blue jelly, ammofly, mites?)
Fight data tables
Can_fight

# Half-implemented features
Exclude Puzzles, Start with Gear

# Will need to do eventually
Webworld, docstrings
MORE DIFFICULTY SETTINGS
tidy up the spoiler log